;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-richeng" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M874.368 1006.464 124.16 1006.464c-37.632 0-68.224-30.528-68.224-68.224L55.936 188.032c0-37.696 30.528-68.224 68.224-68.224l68.224 0 0 34.112c0 56.512 45.824 102.272 102.272 102.272 56.448 0 102.272-45.824 102.272-102.272L396.928 119.872l204.608 0 0 34.112c0 56.512 45.824 102.272 102.272 102.272 56.448 0 102.272-45.824 102.272-102.272L806.08 119.872l68.224 0c37.632 0 68.224 30.528 68.224 68.224L942.528 938.24C942.528 975.872 912 1006.464 874.368 1006.464L874.368 1006.464zM878.912 304 119.616 304l0 638.016 759.296 0L878.912 304 878.912 304zM294.656 498.304 192.384 498.304 192.384 396.032l102.272 0L294.656 498.304 294.656 498.304zM294.656 668.8 192.384 668.8 192.384 566.464l102.272 0L294.656 668.8 294.656 668.8zM294.656 839.296 192.384 839.296l0-102.272 102.272 0L294.656 839.296 294.656 839.296zM465.152 498.304 362.88 498.304 362.88 396.032l102.272 0L465.152 498.304 465.152 498.304zM465.152 668.8 362.88 668.8 362.88 566.464l102.272 0L465.152 668.8 465.152 668.8zM465.152 839.296 362.88 839.296l0-102.272 102.272 0L465.152 839.296 465.152 839.296zM635.648 498.304 533.376 498.304 533.376 396.032l102.272 0L635.648 498.304 635.648 498.304zM635.648 668.8 533.376 668.8 533.376 566.464l102.272 0L635.648 668.8 635.648 668.8zM635.648 839.296 533.376 839.296l0-102.272 102.272 0L635.648 839.296 635.648 839.296zM806.144 498.304l-102.272 0L703.872 396.032l102.272 0L806.144 498.304 806.144 498.304zM806.144 668.8l-102.272 0L703.872 566.464l102.272 0L806.144 668.8 806.144 668.8zM806.144 839.296l-102.272 0 0-102.272 102.272 0L806.144 839.296 806.144 839.296zM702.784 222.144c-37.12 0-67.136-30.08-67.136-67.136L635.648 84.736c0-37.12 30.016-67.136 67.136-67.136 37.12 0 67.136 30.016 67.136 67.136l0 70.336C769.92 192.064 739.904 222.144 702.784 222.144L702.784 222.144zM293.632 222.144c-37.12 0-67.136-30.08-67.136-67.136L226.496 84.736c0-37.12 30.016-67.136 67.136-67.136 37.12 0 67.136 30.016 67.136 67.136l0 70.336C360.768 192.064 330.688 222.144 293.632 222.144L293.632 222.144zM293.632 222.144"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-shizi" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M451.413333 0l121.173333 0 0 1024-121.173333 0 0-1024Z"  ></path>' +
    '' +
    '<path d="M0 451.413333l1024 0 0 121.173333-1024 0 0-121.173333Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-arrowlefticon" viewBox="0 0 1171 1024">' +
    '' +
    '<path d="M1097.162313 584.707482 250.272424 584.707482 562.833701 896.95123C591.749274 925.859979 591.749274 972.659975 562.833701 1001.568724 533.91812 1030.477473 487.058315 1030.477473 458.142742 1001.568724L21.580946 565.451235C6.757449 550.631234-0.361728 531.131238 0.028357 511.679985L0.028357 511.631236 0.028357 511.582486C-0.361728 492.13124 6.757449 472.582488 21.580946 457.762487L458.142742 21.644997C487.058315-7.215002 533.91812-7.215002 562.833701 21.644997 591.749274 50.553746 591.749274 97.4025 562.833701 126.262499L250.272424 438.55499 1097.162313 438.55499C1137.585605 438.55499 1170.304578 471.266238 1170.304578 511.631236 1170.304578 551.947483 1137.585605 584.707482 1097.162313 584.707482L1097.162313 584.707482Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-arrowrighticon" viewBox="0 0 1171 1024">' +
    '' +
    '<path d="M73.136369 584.742936 919.957929 584.742936 607.421857 896.961484C578.508625 925.8679 578.508625 972.664119 607.421857 1001.570534 636.335089 1030.47695 683.191156 1030.47695 712.104388 1001.570534L1148.630928 565.488243C1163.453229 550.669438 1170.571795 531.171017 1170.181755 511.721334L1170.181755 511.672588 1170.181755 511.623842C1170.571795 492.174166 1163.453229 472.626991 1148.630928 457.808187L712.104388 21.725895C683.191156-7.131775 636.335089-7.131775 607.421857 21.725895 578.508625 50.632311 578.508625 97.477283 607.421857 126.334953L919.957929 438.60224 73.136369 438.60224C32.716354 438.60224 0 471.310848 0 511.672588 0 551.985582 32.716354 584.742936 73.136369 584.742936L73.136369 584.742936 73.136369 584.742936Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-richeng2" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M348.55 66.83a28.9 28.9 0 0 0-28.89 28.91v65.68H170.24c-40 0-72.55 32.68-72.55 72.86v650c0 40.18 32.56 72.88 72.55 72.88h683.57c40 0 72.5-32.7 72.5-72.88v-650c0-40.18-32.51-72.86-72.5-72.86H706.64V95.74a28.89 28.89 0 1 0-57.78 0v65.68H377.44V95.74a28.9 28.9 0 0 0-28.89-28.91zM293 899.34H170.24a14.94 14.94 0 0 1-14.77-15.06v-123H293z m0-195.89H155.46V577.62H293z m0-183.66H155.46V398.88H293z m190.11 379.55H350.76V761.28h132.35z m0-195.89H350.76V577.62h132.35z m0-183.66H350.76V398.88h132.35z m187.77 379.55h-130V761.28h130z m0-195.89h-130V577.62h130z m0-183.66h-130V398.88h130z m197.66 364.5c0 8.16-6.78 15.06-14.73 15.06H728.66V761.28h139.88z m0-180.83H728.66V577.62h139.88z m0-183.66H728.66V398.88h139.88zM648.87 219.25V283a28.89 28.89 0 1 0 57.78 0v-63.8h147.16a14.92 14.92 0 0 1 14.73 15v106.86H155.46V234.28a15.12 15.12 0 0 1 14.77-15h149.43V283a28.89 28.89 0 1 0 57.78 0v-63.8z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)